# Welcome to Chat with Your Text File

With this application, you can chat with an uploaded text file that is smaller than 2MB!
